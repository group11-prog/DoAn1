---
                title: "tbsch.de | Smart Home, Technik, Kram"
                tags: [Personal site]
                externalUrl: "https://tbsch.de"
                weight: 104
                showDate: false
                showAuthor: false
                showReadingTime: false
                showEdit: false
                showLikes: false
                showViews: false
                layoutBackgroundHeaderSpace: false
                ---
