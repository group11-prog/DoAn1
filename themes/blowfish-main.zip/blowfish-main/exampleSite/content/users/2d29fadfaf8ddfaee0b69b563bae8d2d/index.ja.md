---
                title: "Hudson McNamara"
                tags: [個人サイト, ブログ]
                externalUrl: "https://hudsonmcnamara.com"
                weight: 88
                showDate: false
                showAuthor: false
                showReadingTime: false
                showEdit: false
                showLikes: false
                showViews: false
                layoutBackgroundHeaderSpace: false
                ---

