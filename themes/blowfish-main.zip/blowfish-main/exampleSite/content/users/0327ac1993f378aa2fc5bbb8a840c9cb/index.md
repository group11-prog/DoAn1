---
                title: "DXPetti.com"
                tags: [Personal site,Blog]
                externalUrl: "https://www.dxpetti.com/"
                weight: 55
                showDate: false
                showAuthor: false
                showReadingTime: false
                showEdit: false
                showLikes: false
                showViews: false
                layoutBackgroundHeaderSpace: false
                ---
