---
                title: "code-chimp.com"
                tags: [Personal site]
                externalUrl: "https://code-chimp.com"
                weight: 3
                showDate: false
                showAuthor: false
                showReadingTime: false
                showEdit: false
                showLikes: false
                showViews: false
                layoutBackgroundHeaderSpace: false
                ---
