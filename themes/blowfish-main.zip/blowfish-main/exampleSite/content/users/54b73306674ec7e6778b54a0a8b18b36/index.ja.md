---
                title: "Handbook on Teaching Empirical Software Engineering: Online Materials"
                tags: [本, 学術界]
                externalUrl: "https://www.emse.education"
                weight: 77
                showDate: false
                showAuthor: false
                showReadingTime: false
                showEdit: false
                showLikes: false
                showViews: false
                layoutBackgroundHeaderSpace: false
                ---

