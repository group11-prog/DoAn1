---
                title: "Handbook on Teaching Empirical Software Engineering: Online Materials"
                tags: [书, 学术界]
                externalUrl: "https://www.emse.education"
                weight: 77
                showDate: false
                showAuthor: false
                showReadingTime: false
                showEdit: false
                showLikes: false
                showViews: false
                layoutBackgroundHeaderSpace: false
                ---

