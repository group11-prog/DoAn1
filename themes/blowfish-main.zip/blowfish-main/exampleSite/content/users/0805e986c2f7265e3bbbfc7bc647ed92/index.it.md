---
                title: "Chill-Try"
                tags: [Blog sulla tecnologia, Sito personale, Blog]
                externalUrl: "https://ctry.tech/"
                weight: 87
                showDate: false
                showAuthor: false
                showReadingTime: false
                showEdit: false
                showLikes: false
                showViews: false
                layoutBackgroundHeaderSpace: false
                ---

