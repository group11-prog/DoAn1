---
                title: "weaxsey.org"
                tags: [個人サイト]
                externalUrl: "https://weaxsey.org/"
                weight: 31
                showDate: false
                showAuthor: false
                showReadingTime: false
                showEdit: false
                showLikes: false
                showViews: false
                layoutBackgroundHeaderSpace: false
                ---

