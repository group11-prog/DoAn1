---
                title: "loisvelasco.is-a.dev"
                tags: [Sito personale]
                externalUrl: "https://loisvelasco.is-a.dev"
                weight: 10
                showDate: false
                showAuthor: false
                showReadingTime: false
                showEdit: false
                showLikes: false
                showViews: false
                layoutBackgroundHeaderSpace: false
                ---

