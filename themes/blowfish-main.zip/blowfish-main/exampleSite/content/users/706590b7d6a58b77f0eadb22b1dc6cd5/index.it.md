---
                title: "The Space 🌍"
                tags: [Sito personale, Blog tecnologico]
                externalUrl: "https://panoskorovesis.github.io/"
                weight: 90
                showDate: false
                showAuthor: false
                showReadingTime: false
                showEdit: false
                showLikes: false
                showViews: false
                layoutBackgroundHeaderSpace: false
                ---

