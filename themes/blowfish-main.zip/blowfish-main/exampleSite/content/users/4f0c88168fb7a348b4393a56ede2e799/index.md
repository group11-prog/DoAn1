---
                title: "renaud.warnotte.be"
                tags: [Personal site]
                externalUrl: "https://renaud.warnotte.be"
                weight: 50
                showDate: false
                showAuthor: false
                showReadingTime: false
                showEdit: false
                showLikes: false
                showViews: false
                layoutBackgroundHeaderSpace: false
                ---
