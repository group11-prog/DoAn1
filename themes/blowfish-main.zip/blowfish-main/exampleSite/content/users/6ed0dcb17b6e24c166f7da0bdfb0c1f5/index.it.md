---
                title: "technicat.com"
                tags: [Sito aziendale]
                externalUrl: "https://technicat.com/"
                weight: 24
                showDate: false
                showAuthor: false
                showReadingTime: false
                showEdit: false
                showLikes: false
                showViews: false
                layoutBackgroundHeaderSpace: false
                ---

