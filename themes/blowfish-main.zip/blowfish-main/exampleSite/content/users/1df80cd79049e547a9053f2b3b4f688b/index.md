---
                title: "Dan Davidson | Where Crypto, Charts and Curiosity Collide"
                tags: [Personal site,Technology Blog]
                externalUrl: "https://danly.io"
                weight: 103
                showDate: false
                showAuthor: false
                showReadingTime: false
                showEdit: false
                showLikes: false
                showViews: false
                layoutBackgroundHeaderSpace: false
                ---
