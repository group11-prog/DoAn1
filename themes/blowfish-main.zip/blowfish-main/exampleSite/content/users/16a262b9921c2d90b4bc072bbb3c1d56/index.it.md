---
                title: "metalhearf.fr"
                tags: [Blog, Sito personale]
                externalUrl: "https://metalhearf.fr"
                weight: 105
                showDate: false
                showAuthor: false
                showReadingTime: false
                showEdit: false
                showLikes: false
                showViews: false
                layoutBackgroundHeaderSpace: false
                ---

