---
                title: "Middle of Nowhere"
                tags: [个人网站, 博客]
                externalUrl: "https://blog.wtcx.dev/"
                weight: 68
                showDate: false
                showAuthor: false
                showReadingTime: false
                showEdit: false
                showLikes: false
                showViews: false
                layoutBackgroundHeaderSpace: false
                ---

