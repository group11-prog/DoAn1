---
                title: "FEEC/UNICAMP IA382 - Seminar in Computer Engineering"
                tags: [セミナー, クラス]
                externalUrl: "https://feec-seminar-comp-eng.github.io/"
                weight: 94
                showDate: false
                showAuthor: false
                showReadingTime: false
                showEdit: false
                showLikes: false
                showViews: false
                layoutBackgroundHeaderSpace: false
                ---

