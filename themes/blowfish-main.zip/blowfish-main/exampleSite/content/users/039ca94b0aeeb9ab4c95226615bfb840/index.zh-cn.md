---
                title: "dizzytech.de"
                tags: [个人网站]
                externalUrl: "https://dizzytech.de"
                weight: 17
                showDate: false
                showAuthor: false
                showReadingTime: false
                showEdit: false
                showLikes: false
                showViews: false
                layoutBackgroundHeaderSpace: false
                ---

