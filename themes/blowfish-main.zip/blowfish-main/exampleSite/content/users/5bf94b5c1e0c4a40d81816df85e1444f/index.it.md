---
                title: "pmnxis.github.io"
                tags: [Sito personale]
                externalUrl: "https://pmnxis.github.io"
                weight: 6
                showDate: false
                showAuthor: false
                showReadingTime: false
                showEdit: false
                showLikes: false
                showViews: false
                layoutBackgroundHeaderSpace: false
                ---

