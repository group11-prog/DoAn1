---
                title: "pmnxis.github.io"
                tags: [个人网站]
                externalUrl: "https://pmnxis.github.io"
                weight: 6
                showDate: false
                showAuthor: false
                showReadingTime: false
                showEdit: false
                showLikes: false
                showViews: false
                layoutBackgroundHeaderSpace: false
                ---

